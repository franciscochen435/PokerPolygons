package cs3500.pokerpolygons.model.hw02;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Test some methods which is not defined in start code.
 * Including getRank() and getSuit().
 * Which can also verify the constructor of Poker.
 */
public class TestPokerPolygonsPrivate {
  private Poker c1;
  private Poker c2;
  private Poker c3;
  private Poker c4;

  @Before
  public void setUp() {
    this.c1 = new Poker(1, "♣");
    this.c2 = new Poker(13, "♡");
    this.c3 = new Poker(4, "♢");
    this.c4 = new Poker(10, "♠");
  }

  @Test
  public void testValidPokerConstructor() {
    assertEquals(1, this.c1.getRank());
    assertEquals("♣", this.c1.getSuit());
    assertEquals(13, this.c2.getRank());
    assertEquals("♡", this.c2.getSuit());
    assertEquals(4, this.c3.getRank());
    assertEquals("♢", this.c3.getSuit());
    assertEquals(10, this.c4.getRank());
    assertEquals("♠", this.c4.getSuit());
    assertEquals("red", this.c2.getColor());
    assertEquals("red", this.c3.getColor());
    assertEquals("black", this.c1.getColor());
    assertEquals("black", this.c4.getColor());

  }
}